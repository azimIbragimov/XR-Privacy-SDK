#if UNITY_2020_2_OR_NEWER
[assembly: UnityEditor.Localization]
#endif