﻿using UnityEngine;

namespace FMODUnity
{
    public class BankRefAttribute : PropertyAttribute
    {
    }
}
